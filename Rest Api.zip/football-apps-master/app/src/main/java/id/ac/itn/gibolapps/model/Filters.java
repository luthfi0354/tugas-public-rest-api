package id.ac.itn.gibolapps.model;

public class Filters{

}
