package id.ac.itn.gibolapps.model;

import java.io.Serializable;

public class Odds implements Serializable {
	private String msg;

	public void setMsg(String msg){
		this.msg = msg;
	}

	public String getMsg(){
		return msg;
	}
}